# mcp-router

Park several MCP servers behind **one** MCP endpoint, routed by `session_id`.

A backend is either spawned by the router (`stdio`) or dials in and registers a
session over WebSocket (`ws`). The facade presents one merged tool catalog; a
call names a tool and a session, and the router picks the backend *instance*
that must serve it.

## Why sessions, not just a proxy

A plain aggregating proxy merges tool names. That is not enough when a backend
keeps state inside its own process. `@cyanheads/git-mcp-server` is the case that
motivated this: it remembers a working directory per tenant, defaulting to a
single `default-tenant` slot. Share one instance across two workspaces and the
last `git_set_working_dir` wins — the other session's next commit lands in the
wrong repository, silently.

The router's answer is the scope declared in config:

| scope | meaning | use for |
|---|---|---|
| `singleton` | one shared instance for all sessions | stateless backends |
| `per-session` | one instance per session id | **any** backend with per-process state |

`per-session` is not an optimisation. It is the invariant that makes stateful
backends safe: a session's state cannot be observed by another session because
there is no shared process to observe.

## Config

```yaml
port: 27681
host: 0.0.0.0
mcpPath: /mcp          # default
wsPath: /ws            # default
callTimeoutMs: 300000

backends:
  - name: vscode
    transport: ws      # windows dial in; nothing can spawn them
    prefix: vscode
    scope: per-session

  - name: git
    transport: stdio   # router spawns one child per session
    command: git-mcp-server
    args: []
    env:
      GIT_BASE_DIR: /workspace
    scope: per-session
    lazy: true         # start on first call, not at boot
```

Validation is strict and fails fast: unknown transport, a `ws` backend that also
declares a command, duplicate names, two backends sharing a prefix, a
non-integer port. Misconfiguration should be a startup error, not a 3am
surprise.

## Contracts

**`session_id` is consumed by the router and never forwarded.** Backend input
schemas are strict — a foreign key is an error, not a hint. Cross-cutting
metadata belongs at the protocol level (`params._meta`), not in a tool's input
schema.

**Routing keys are stripped, names are mapped.** `git_status` with
`prefix: git` reaches the backend as `git_status` (or as `status` for a backend
that names its tools bare). Nothing downstream learns the facade's routing
vocabulary.

**Tool names are the backend's own.** Prefixes are optional and additive. Note
that `@cyanheads/git-mcp-server` already names its tools `git_*`, so give that
backend **no prefix** or you will advertise `git_git_status` and put the policy
surface in the gateway out of step with the real names.

**`list_tools` is an extension to the WS protocol.** A backend that answers it
advertises its tools live; one that does not falls back to declaring them in the
router config.

## The WS protocol (frozen)

The `ws` transport speaks the existing vscode-mcp satellite protocol so running
VS Code windows keep working unchanged. The router accepts these on `wsPath`:

| message | direction | payload |
|---|---|---|
| `register` | backend → router | `{ sessionId }` |
| `registered` | router → backend | `{ sessionId }` |
| `execute` | router → backend | `{ requestId, tool, params }` |
| `result` | backend → router | `{ requestId, result }` |
| `error` | backend → router | `{ requestId, message }` |
| `list_tools` / `list_tools_result` | both | `{ requestId }` / `{ requestId, tools }` |
| `ping` / `pong` | both | keepalive |

Treat this table as a contract: changing it breaks deployed windows.

## HTTP surface

| route | purpose |
|---|---|
| `POST /mcp` | MCP JSON-RPC (`initialize`, `tools/list`, `tools/call`) |
| `GET /health` | liveness + configured backend names |
| `GET /sessions` | session ids currently known |
| `WS /ws` | backend registrations |

## Usage

```bash
npm install
npm run build

node dist/main.js --config router.yaml
node dist/main.js --config router.yaml --print-tools   # list the catalog and exit
```

## Tests

```bash
npm test
```

The suite starts real MCP servers as fixtures. The ones that matter:

- **isolation** — two sessions set different state and cannot see each other's
- **no leakage after drop** — a session that reconnects gets a fresh process,
  not a stale value
- **`session_id` not forwarded** — the fixture declares
  `additionalProperties: false`, so a forwarded key would fail the call
- **singleton sharing is visible** — proves *why* stateful backends must declare
  `per-session`
- **discovery never runs on a session's instance** — the probe instance keeps
  its own `call_log`, so tool listing cannot pollute real session state
- **WS satellite** — an extension-shaped client registered, routed to by
  session, correct window receiving the call

## Layout

```
src/
  main.ts             CLI entrypoint
  config.ts           parse + validate router.yaml
  types.ts            config/instance contracts
  router.ts           session table, catalog, dispatch invariants
  facade.ts           HTTP/JSON-RPC front end
  relay.ts            WS wire protocol + request correlation
  backends/
    stdio.ts          spawn a child and speak MCP to it
    ws.ts             accept registrations from clients that dial in
```
